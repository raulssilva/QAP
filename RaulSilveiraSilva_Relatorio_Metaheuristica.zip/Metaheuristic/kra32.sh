./meta-heuristico Instâncias/kra32.dat 1
sleep 1
./meta-heuristico Instâncias/kra32.dat 2
sleep 1
./meta-heuristico Instâncias/kra32.dat 3
sleep 1
./meta-heuristico Instâncias/kra32.dat 4
sleep 1
./meta-heuristico Instâncias/kra32.dat 5
sleep 1
./meta-heuristico Instâncias/kra32.dat 6
sleep 1
./meta-heuristico Instâncias/kra32.dat 7
sleep 1
./meta-heuristico Instâncias/kra32.dat 8
sleep 1
./meta-heuristico Instâncias/kra32.dat 9
sleep 1
./meta-heuristico Instâncias/kra32.dat 10
sleep 1
./meta-heuristico Instâncias/kra32.dat 11
sleep 1
./meta-heuristico Instâncias/kra32.dat 12
sleep 1
./meta-heuristico Instâncias/kra32.dat 13
sleep 1
./meta-heuristico Instâncias/kra32.dat 14
sleep 1
./meta-heuristico Instâncias/kra32.dat 15
sleep 1
./meta-heuristico Instâncias/kra32.dat 16
sleep 1
./meta-heuristico Instâncias/kra32.dat 17
sleep 1
./meta-heuristico Instâncias/kra32.dat 18
sleep 1
./meta-heuristico Instâncias/kra32.dat 19
sleep 1
./meta-heuristico Instâncias/kra32.dat 20
sleep 1
./meta-heuristico Instâncias/kra32.dat 21
sleep 1
./meta-heuristico Instâncias/kra32.dat 22
sleep 1
./meta-heuristico Instâncias/kra32.dat 23
sleep 1
./meta-heuristico Instâncias/kra32.dat 24
sleep 1
./meta-heuristico Instâncias/kra32.dat 25
sleep 1
./meta-heuristico Instâncias/kra32.dat 26
sleep 1
./meta-heuristico Instâncias/kra32.dat 27
sleep 1
./meta-heuristico Instâncias/kra32.dat 28
sleep 1
./meta-heuristico Instâncias/kra32.dat 29
sleep 1
./meta-heuristico Instâncias/kra32.dat 30