./meta-heuristico Instâncias/esc16a.dat 1
sleep 1
./meta-heuristico Instâncias/esc16a.dat 2
sleep 1
./meta-heuristico Instâncias/esc16a.dat 3
sleep 1
./meta-heuristico Instâncias/esc16a.dat 4
sleep 1
./meta-heuristico Instâncias/esc16a.dat 5
sleep 1
./meta-heuristico Instâncias/esc16a.dat 6
sleep 1
./meta-heuristico Instâncias/esc16a.dat 7
sleep 1
./meta-heuristico Instâncias/esc16a.dat 8
sleep 1
./meta-heuristico Instâncias/esc16a.dat 9
sleep 1
./meta-heuristico Instâncias/esc16a.dat 10
sleep 1
./meta-heuristico Instâncias/esc16a.dat 11
sleep 1
./meta-heuristico Instâncias/esc16a.dat 12
sleep 1
./meta-heuristico Instâncias/esc16a.dat 13
sleep 1
./meta-heuristico Instâncias/esc16a.dat 14
sleep 1
./meta-heuristico Instâncias/esc16a.dat 15
sleep 1
./meta-heuristico Instâncias/esc16a.dat 16
sleep 1
./meta-heuristico Instâncias/esc16a.dat 17
sleep 1
./meta-heuristico Instâncias/esc16a.dat 18
sleep 1
./meta-heuristico Instâncias/esc16a.dat 19
sleep 1
./meta-heuristico Instâncias/esc16a.dat 20
sleep 1
./meta-heuristico Instâncias/esc16a.dat 21
sleep 1
./meta-heuristico Instâncias/esc16a.dat 22
sleep 1
./meta-heuristico Instâncias/esc16a.dat 23
sleep 1
./meta-heuristico Instâncias/esc16a.dat 24
sleep 1
./meta-heuristico Instâncias/esc16a.dat 25
sleep 1
./meta-heuristico Instâncias/esc16a.dat 26
sleep 1
./meta-heuristico Instâncias/esc16a.dat 27
sleep 1
./meta-heuristico Instâncias/esc16a.dat 28
sleep 1
./meta-heuristico Instâncias/esc16a.dat 29
sleep 1
./meta-heuristico Instâncias/esc16a.dat 30