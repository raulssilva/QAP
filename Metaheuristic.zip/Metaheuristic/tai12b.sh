./meta-heuristico Instâncias/tai12b.dat 1
sleep 1
./meta-heuristico Instâncias/tai12b.dat 2
sleep 1
./meta-heuristico Instâncias/tai12b.dat 3
sleep 1
./meta-heuristico Instâncias/tai12b.dat 4
sleep 1
./meta-heuristico Instâncias/tai12b.dat 5
sleep 1
./meta-heuristico Instâncias/tai12b.dat 6
sleep 1
./meta-heuristico Instâncias/tai12b.dat 7
sleep 1
./meta-heuristico Instâncias/tai12b.dat 8
sleep 1
./meta-heuristico Instâncias/tai12b.dat 9
sleep 1
./meta-heuristico Instâncias/tai12b.dat 10
sleep 1
./meta-heuristico Instâncias/tai12b.dat 11
sleep 1
./meta-heuristico Instâncias/tai12b.dat 12
sleep 1
./meta-heuristico Instâncias/tai12b.dat 13
sleep 1
./meta-heuristico Instâncias/tai12b.dat 14
sleep 1
./meta-heuristico Instâncias/tai12b.dat 15
sleep 1
./meta-heuristico Instâncias/tai12b.dat 16
sleep 1
./meta-heuristico Instâncias/tai12b.dat 17
sleep 1
./meta-heuristico Instâncias/tai12b.dat 18
sleep 1
./meta-heuristico Instâncias/tai12b.dat 19
sleep 1
./meta-heuristico Instâncias/tai12b.dat 20
sleep 1
./meta-heuristico Instâncias/tai12b.dat 21
sleep 1
./meta-heuristico Instâncias/tai12b.dat 22
sleep 1
./meta-heuristico Instâncias/tai12b.dat 23
sleep 1
./meta-heuristico Instâncias/tai12b.dat 24
sleep 1
./meta-heuristico Instâncias/tai12b.dat 25
sleep 1
./meta-heuristico Instâncias/tai12b.dat 26
sleep 1
./meta-heuristico Instâncias/tai12b.dat 27
sleep 1
./meta-heuristico Instâncias/tai12b.dat 28
sleep 1
./meta-heuristico Instâncias/tai12b.dat 29
sleep 1
./meta-heuristico Instâncias/tai12b.dat 30