./meta-heuristico Instâncias/tai15a.dat 1
sleep 1
./meta-heuristico Instâncias/tai15a.dat 2
sleep 1
./meta-heuristico Instâncias/tai15a.dat 3
sleep 1
./meta-heuristico Instâncias/tai15a.dat 4
sleep 1
./meta-heuristico Instâncias/tai15a.dat 5
sleep 1
./meta-heuristico Instâncias/tai15a.dat 6
sleep 1
./meta-heuristico Instâncias/tai15a.dat 7
sleep 1
./meta-heuristico Instâncias/tai15a.dat 8
sleep 1
./meta-heuristico Instâncias/tai15a.dat 9
sleep 1
./meta-heuristico Instâncias/tai15a.dat 10
sleep 1
./meta-heuristico Instâncias/tai15a.dat 11
sleep 1
./meta-heuristico Instâncias/tai15a.dat 12
sleep 1
./meta-heuristico Instâncias/tai15a.dat 13
sleep 1
./meta-heuristico Instâncias/tai15a.dat 14
sleep 1
./meta-heuristico Instâncias/tai15a.dat 15
sleep 1
./meta-heuristico Instâncias/tai15a.dat 16
sleep 1
./meta-heuristico Instâncias/tai15a.dat 17
sleep 1
./meta-heuristico Instâncias/tai15a.dat 18
sleep 1
./meta-heuristico Instâncias/tai15a.dat 19
sleep 1
./meta-heuristico Instâncias/tai15a.dat 20
sleep 1
./meta-heuristico Instâncias/tai15a.dat 21
sleep 1
./meta-heuristico Instâncias/tai15a.dat 22
sleep 1
./meta-heuristico Instâncias/tai15a.dat 23
sleep 1
./meta-heuristico Instâncias/tai15a.dat 24
sleep 1
./meta-heuristico Instâncias/tai15a.dat 25
sleep 1
./meta-heuristico Instâncias/tai15a.dat 26
sleep 1
./meta-heuristico Instâncias/tai15a.dat 27
sleep 1
./meta-heuristico Instâncias/tai15a.dat 28
sleep 1
./meta-heuristico Instâncias/tai15a.dat 29
sleep 1
./meta-heuristico Instâncias/tai15a.dat 30