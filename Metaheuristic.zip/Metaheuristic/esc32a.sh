./meta-heuristico Instâncias/esc32a.dat 1
sleep 1
./meta-heuristico Instâncias/esc32a.dat 2
sleep 1
./meta-heuristico Instâncias/esc32a.dat 3
sleep 1
./meta-heuristico Instâncias/esc32a.dat 4
sleep 1
./meta-heuristico Instâncias/esc32a.dat 5
sleep 1
./meta-heuristico Instâncias/esc32a.dat 6
sleep 1
./meta-heuristico Instâncias/esc32a.dat 7
sleep 1
./meta-heuristico Instâncias/esc32a.dat 8
sleep 1
./meta-heuristico Instâncias/esc32a.dat 9
sleep 1
./meta-heuristico Instâncias/esc32a.dat 10
sleep 1
./meta-heuristico Instâncias/esc32a.dat 11
sleep 1
./meta-heuristico Instâncias/esc32a.dat 12
sleep 1
./meta-heuristico Instâncias/esc32a.dat 13
sleep 1
./meta-heuristico Instâncias/esc32a.dat 14
sleep 1
./meta-heuristico Instâncias/esc32a.dat 15
sleep 1
./meta-heuristico Instâncias/esc32a.dat 16
sleep 1
./meta-heuristico Instâncias/esc32a.dat 17
sleep 1
./meta-heuristico Instâncias/esc32a.dat 18
sleep 1
./meta-heuristico Instâncias/esc32a.dat 19
sleep 1
./meta-heuristico Instâncias/esc32a.dat 20
sleep 1
./meta-heuristico Instâncias/esc32a.dat 21
sleep 1
./meta-heuristico Instâncias/esc32a.dat 22
sleep 1
./meta-heuristico Instâncias/esc32a.dat 23
sleep 1
./meta-heuristico Instâncias/esc32a.dat 24
sleep 1
./meta-heuristico Instâncias/esc32a.dat 25
sleep 1
./meta-heuristico Instâncias/esc32a.dat 26
sleep 1
./meta-heuristico Instâncias/esc32a.dat 27
sleep 1
./meta-heuristico Instâncias/esc32a.dat 28
sleep 1
./meta-heuristico Instâncias/esc32a.dat 29
sleep 1
./meta-heuristico Instâncias/esc32a.dat 30